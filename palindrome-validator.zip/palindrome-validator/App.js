import { Alert, Button, Image, Text, TextInput, View } from "react-native";
import React from 'react'; 

const palindrome = (str) => {
  str = str.toLowerCase().replace(/[\W_]/g, '');
  return str === str.split('').reverse().join('');
};

export default function App(){
  const [inputText, setInputText] = React.useState('');

  const PalindromeValidator = () => {
    if (palindrome(inputText)) {
      Alert.alert('Palindrome', 'Kata palindrome.');
    } else {
      Alert.alert('Bukan Palindrome', 'Bukan kata palindrome.');
    }
  };
  return(
    <View style={{
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    }}>
      <Text style={{
        fontSize: 20,
        fontWeight: 'bold',
        color: 'black',
      }}>Palindrome Validator</Text>
      <Image 
        style={{
          width: 200,
          height: 200,
        }}
        source={{uri: 'https://cdn0-production-images-kly.akamaized.net/wB5FxqxOhKwEzf-W9DlAoN5u2vA=/800x1066/smart/filters:quality(75):strip_icc():format(webp)/kly-media-production/medias/4048846/original/069460100_1654851647-aaron-burden-2IzoIHBgYAo-unsplash.jpg'}}
      />
      <TextInput 
      style={{
        borderWidth: 1,
        borderColor: 'black',
        width: 200,
        height: 40,
        padding: 10,
        margin: 10,
        borderRadius: 10,
      }}
      placeholder="Masukkan Teks"
      onChangeText={(text) => setInputText(text)}
        value={inputText}
      />
      <Button
      title="Validasi"
      onPress={PalindromeValidator}
      />
    </View>
  );
}